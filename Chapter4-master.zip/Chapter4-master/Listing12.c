struct phys_state {
   double density;
   double momentum[3];
   double TotEnergy;
};

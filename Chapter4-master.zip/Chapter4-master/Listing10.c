struct hash_type {
   int key;
   int value;
};
struct hash_type hash[1000];

int main(int argc, char *argv[]){
   struct RGB {
      int R;
      int G;
      int B;
   };
   struct RGB polygon_color[1000];
}

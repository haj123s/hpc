# EssentialsOfParallelComputing
Main Book repository for the Parallel and High Performance Computing book, Manning Publications

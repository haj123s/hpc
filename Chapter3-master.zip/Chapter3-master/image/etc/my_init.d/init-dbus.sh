#!/bin/bash
# start up dbus service

/etc/init.d/dbus start

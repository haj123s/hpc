#include <stdio.h>

int main(int argc, char **argv)
{
   printf("\n\t\tRunning the ezcl tests\n\n");

   // Find the OpenCL device

   printf("\n\t\tFinished the ezcl tests\n\n");
}

#ifndef _PLACE_REPORT_H
#define _PLACE_REPORT_H
void place_report_mpi_omp(void);
void place_report_mpi(void);
void place_report_mpi_quo(QUO_context quo);
#endif

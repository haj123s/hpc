#ifndef _PLACE_REPORT_MPI_OMP_H
#define _PLACE_REPORT_MPI_OMP_H
void place_report_mpi_omp(void);
#endif

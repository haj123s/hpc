#ifndef _PLACE_REPORT_OMP_H
#define _PLACE_REPORT_OMP_H
void place_report_omp(void);
#endif

#ifndef _PLACE_REPORT_MPI_H
#define _PLACE_REPORT_MPI_H
void place_report_mpi(void);
#endif

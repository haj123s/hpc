#ifndef MALLOC2DFORT_H
#define MALLOC2DFORT_H
double **malloc2Dfort_dbl(int jmax, int imax);
int    **malloc2Dfort_int(int jmax, int imax);
#endif

#ifndef MAX_REDUCTION_H
#define MAX_REDUCTION_H
double array_max(double* restrict var, int ncells);
#endif

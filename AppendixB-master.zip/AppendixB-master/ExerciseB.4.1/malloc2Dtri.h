double **malloc2Dtri(int jmax, int imax);

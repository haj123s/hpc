#ifndef _SHALLOWWATER_H
#define _SHALLOWWATER_H
#define wait_time 0        // Slows down run if too fast
#define debug 0            // Turn on debug statements
#define check 1            // Checks mass conservation
#define display_on 10      // Turns on output and skips this many cycles between plots
#endif

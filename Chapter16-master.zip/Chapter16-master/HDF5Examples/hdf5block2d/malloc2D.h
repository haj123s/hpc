#ifndef _MALLOC2D_H
#define _MALLOC2D_H
double **malloc2D(int jmax, int imax);
#endif

#include "vectorclass/vectorclass.h"

Vec4d local_sum(0.0);

int main(int argc, char *argv[]){
}

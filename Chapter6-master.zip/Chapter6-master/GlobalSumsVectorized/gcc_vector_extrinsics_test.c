typedef double vec4d __attribute__ ((vector_size(4 * sizeof(double))));
vec4d local_sum;

int main(int argc, char *argv[]){
}

#include <x86intrin.h>

__m256d local_sum;

int main(int argc, char *argv[]){
}

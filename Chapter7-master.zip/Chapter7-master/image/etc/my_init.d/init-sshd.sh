#!/bin/bash
# start up sshd service

/etc/init.d/ssh start

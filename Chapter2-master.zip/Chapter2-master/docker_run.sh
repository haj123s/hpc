#!/bin/sh
docker run -it --entrypoint /bin/bash essentialsofparallelcomputing/chapter2
